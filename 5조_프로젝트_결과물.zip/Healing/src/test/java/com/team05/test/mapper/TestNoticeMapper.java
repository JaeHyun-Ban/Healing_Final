package com.team05.test.mapper;

import com.team05.command.NoticeVO;

public interface TestNoticeMapper {
	
//	public int insertTEst(notice)
	
	public void regist(NoticeVO vo);
	
	
}
